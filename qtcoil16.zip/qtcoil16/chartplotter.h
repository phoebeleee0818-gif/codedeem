#ifndef CHARTPLOTTER_H
#define CHARTPLOTTER_H

#include <QObject>
#include <QVector>

class QCustomPlot;

class ChartPlotter
{
public:
    ChartPlotter(QCustomPlot* plotI, QCustomPlot* plotQ);
    void drawBarChart(const QVector<QVector<qreal>>& data);


private:
    void setupPlots();

    QCustomPlot* customPlot_I;
    QCustomPlot* customPlot_Q;
};

#endif // PLOTDATAWORKER_H
