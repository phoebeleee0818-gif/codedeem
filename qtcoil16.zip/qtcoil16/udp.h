#ifndef UDP_H
#define UDP_H

#include <QObject>
#include <QUdpSocket>
#include <QNetworkDatagram>
#include <QDebug>
#include <QThread>
#include <QtMath>

class udp : public QObject
{
    Q_OBJECT
public:
    explicit udp(QObject *parent = nullptr);
    ~udp();

    QUdpSocket *pc_sock;
    QUdpSocket *device_sock;

    bool send_data(const QByteArray& data);

private:
    QString pc_ip, device_ip;
    qint16 PC_PORT = 4592, DEVICE_PORT = 4590;

    bool connect_state = false;


signals:
    void emit_raw_data(QByteArray raw_data);
    void emit_frequency_list(QList<qreal> frequencies);

public slots:
    void init();
    bool udp_connect_toggle(const QString& pc_ip, const QString& device_ip);
    void receive_data();
    bool get_connect_state();
};

#endif // UDP_H
