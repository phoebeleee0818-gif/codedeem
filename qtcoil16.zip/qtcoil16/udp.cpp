#include "udp.h"

udp::udp(QObject *parent)
    : QObject{parent}
{
    init();
}

udp::~udp(){}

void udp::init(){
    pc_sock = new QUdpSocket(this);
    device_sock = new QUdpSocket(this);

    connect(pc_sock, &QUdpSocket::readyRead, this, &udp::receive_data);
}

bool udp::udp_connect_toggle(const QString& pc_ip, const QString& device_ip){
    this->pc_ip = pc_ip;
    this->device_ip = device_ip;

    if (!connect_state){
        bool is_connected = pc_sock->bind(QHostAddress(this->pc_ip), PC_PORT);

        if (is_connected){
            connect_state = true;
        }
        else{
            connect_state = false;
        }
    }
    else{
        connect_state = false;
        pc_sock->abort();
    }

    qDebug() << connect_state;
    return connect_state;
}

bool udp::get_connect_state(){
    return connect_state;
}

void udp::receive_data(){
    while (pc_sock->hasPendingDatagrams()){
        QByteArray raw_data = pc_sock->receiveDatagram().data();
        emit emit_raw_data(raw_data);
    }
}

bool udp::send_data(const QByteArray& data){
    if (connect_state){
            qint64 len = device_sock->writeDatagram(data, QHostAddress(device_ip), DEVICE_PORT);

            if (len == -1){
                qDebug() << "Send Failed: " << data;
                return false;
            }
        qDebug() << "Send Success: " << data;
        return true;
    }
    qDebug() << "Send Failed: " << data;
    return false;
}
