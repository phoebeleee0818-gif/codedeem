#ifndef DATA_PROCESS_H
#define DATA_PROCESS_H

#include <QObject>
#include <QCoreApplication>
#include <QByteArray>
#include <QtEndian>
#include <QtMath>
#include <QDebug>
#include <QMutexLocker>
#include <QThread>
#include <QFuture>
#include <QtConcurrent>
// #include <stdexcept>

class data_process : public QObject
{
    Q_OBJECT
public:
    explicit data_process(QObject *parent = nullptr);

    int data_received = 0;

    int get_perf_data();
    void reset_perf_data();
    QVector<QVector<qreal>> decoded_data_buffer;


private:
    QMutex mutex;

    int data_index = 0;
    const int SAMPLE_SIZE = 32;

    QVector<qreal> decode_block(const QByteArray &block_data);

    QString data_save_path;
    bool need_save_data = false;


signals:
    void send_decoded_data(QVector<QVector<qreal>> decoded_data_buffer);


public slots:
    void decode_data(const QByteArray &raw_data);
};

#endif // DATA_PROCESS_H
