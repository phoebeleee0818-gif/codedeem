#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QtConcurrent>
#include <QThread>
#include <QUdpSocket>

#include "udp.h"
#include "data_process.h"
#include "chartplotter.h"
// #include "plotdataworker.h"



QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void save_data_to_csv(const QVector<QVector<qreal>>& decoded_data_buffer,const QVector<QDateTime>&timestamp_buffer);



private:
    Ui::MainWindow *ui;

    QUdpSocket *udpSocket;
    QUdpSocket *udpSocketOut;

    udp *udp_data;
    data_process *data;
    QThread *data_thread;

    QTimer *perf_timer;

    void init();
    void set_connect();

    QVector<quint16> phaseOffsetArray = {10, 20, 30, 40, 50};
    QString data_save_path;
    QVector<QVector<qreal>> recordingBuffer;
    QVector<QDateTime>     timestampBuffer;

    bool isRecording = false;
    QTimer* recordingTimer = nullptr;

    ChartPlotter* chartPlotter;


    QVector<QVector<qreal>> currentGroupCache;
    QVector<QVector<QVector<qreal>>> fullGroups;
    QVector<QVector<qreal>> plot_buffer;

    QVector<QVector<qreal>> tempChannelRows;
    QVector<QVector<qreal>> oneGroup;
    QVector<QVector<QVector<qreal>>> groupQueue;


    void tryExtractOrderedGroup(const QVector<QVector<qreal>>& dataStream);





private slots:
    void perf_monitor();
    void udp_connect_toggle();

    void SendConfiguration_button();
    void SendSendingSequence_button();
    void SendExcitationSequence_button();
    void SendFrequency_button();

    void updateRealtimeDisplay(const QVector<QVector<qreal>> &data);


    void select_data_save_path_button();
    void startRecording();
    void stopRecording();
    void on_new_decoded_data(const QVector<QVector<qreal>> &data);


    void on_startPlotButton_clicked();



};
#endif // MAINWINDOW_H
