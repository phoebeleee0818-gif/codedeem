#include "chartplotter.h"
#include <QPen>
#include <QBrush>
#include "qcustomplot.h"

ChartPlotter::ChartPlotter(QCustomPlot* plotI, QCustomPlot* plotQ)
    : customPlot_I(plotI), customPlot_Q(plotQ)
{
    setupPlots();
}

void ChartPlotter::setupPlots()
{
    // Setup axes and grid (use customPlot_I as an example, Q is similar)
    if (customPlot_I) {
        customPlot_I->xAxis->setLabel("Channel");
        customPlot_I->yAxis->setLabel("Amplitude");

        customPlot_I->xAxis->setRange(0, 126);
        customPlot_I->yAxis->setRange(0, 0.25);
        customPlot_I->xAxis->setAutoTickStep(false);
        customPlot_I->xAxis->setTickStep(5);
        customPlot_I->xAxis->setAutoTicks(true);

        // Black background with white text
        customPlot_I->setBackground(Qt::black);
        customPlot_I->xAxis->setBasePen(QPen(Qt::white));
        customPlot_I->yAxis->setBasePen(QPen(Qt::white));
        customPlot_I->xAxis->setTickPen(QPen(Qt::white));
        customPlot_I->yAxis->setTickPen(QPen(Qt::white));
        customPlot_I->xAxis->setSubTickPen(QPen(Qt::white));
        customPlot_I->yAxis->setSubTickPen(QPen(Qt::white));
        customPlot_I->xAxis->setTickLabelColor(Qt::white);
        customPlot_I->yAxis->setTickLabelColor(Qt::white);
        customPlot_I->xAxis->setLabelColor(Qt::white);
        customPlot_I->yAxis->setLabelColor(Qt::white);

        // Grid lines
        customPlot_I->xAxis->grid()->setVisible(true);
        customPlot_I->yAxis->grid()->setVisible(true);
        customPlot_I->xAxis->grid()->setPen(QPen(Qt::yellow));
        customPlot_I->yAxis->grid()->setPen(QPen(Qt::yellow));
        customPlot_I->xAxis->grid()->setSubGridVisible(true);
        customPlot_I->yAxis->grid()->setSubGridVisible(true);
        customPlot_I->xAxis->grid()->setSubGridPen(QPen(Qt::darkYellow));
        customPlot_I->yAxis->grid()->setSubGridPen(QPen(Qt::darkYellow));
    }

    if (customPlot_Q) {
        // Setup axis labels
        customPlot_Q->xAxis->setLabel("Channel");
        customPlot_Q->yAxis->setLabel("Amplitude");

        // Setup axis ranges
        customPlot_Q->xAxis->setRange(0, 126);
        customPlot_Q->yAxis->setRange(0, 0.25);

        customPlot_Q->xAxis->setAutoTickStep(false);
        customPlot_Q->xAxis->setTickStep(5);
        customPlot_Q->xAxis->setAutoTicks(true);

        // Setup background and colors
        customPlot_Q->setBackground(Qt::black);
        customPlot_Q->xAxis->setBasePen(QPen(Qt::white));
        customPlot_Q->yAxis->setBasePen(QPen(Qt::white));
        customPlot_Q->xAxis->setTickPen(QPen(Qt::white));
        customPlot_Q->yAxis->setTickPen(QPen(Qt::white));
        customPlot_Q->xAxis->setSubTickPen(QPen(Qt::white));
        customPlot_Q->yAxis->setSubTickPen(QPen(Qt::white));
        customPlot_Q->xAxis->setTickLabelColor(Qt::white);
        customPlot_Q->yAxis->setTickLabelColor(Qt::white);
        customPlot_Q->xAxis->setLabelColor(Qt::white);
        customPlot_Q->yAxis->setLabelColor(Qt::white);

        // Grid
        customPlot_Q->xAxis->grid()->setVisible(true);
        customPlot_Q->yAxis->grid()->setVisible(true);
        customPlot_Q->xAxis->grid()->setPen(QPen(Qt::yellow));
        customPlot_Q->yAxis->grid()->setPen(QPen(Qt::yellow));
        customPlot_Q->xAxis->grid()->setSubGridVisible(true);
        customPlot_Q->yAxis->grid()->setSubGridVisible(true);
        customPlot_Q->xAxis->grid()->setSubGridPen(QPen(Qt::darkYellow));
        customPlot_Q->yAxis->grid()->setSubGridPen(QPen(Qt::darkYellow));
    }

}

void ChartPlotter::drawBarChart(const QVector<QVector<qreal>>& data)
{
    if (!customPlot_I || !customPlot_Q || data.size() != 120) return;

    QVector<double> x, yI, yQ;

    for (int i = 0; i < data.size(); ++i) {
        x.append(i);
        yI.append(data[i][5]);
        yQ.append(data[i][7]);
    }

    customPlot_I->clearPlottables();
    customPlot_Q->clearPlottables();

    QCPBars* barsI = new QCPBars(customPlot_I->xAxis, customPlot_I->yAxis);
    QCPBars* barsQ = new QCPBars(customPlot_Q->xAxis, customPlot_Q->yAxis);

    barsI->setPen(QPen(Qt::white));
    barsI->setBrush(QBrush(Qt::white));
    barsQ->setPen(QPen(Qt::white));
    barsQ->setBrush(QBrush(Qt::white));

    barsI->setData(x, yI);
    barsQ->setData(x, yQ);

    customPlot_I->xAxis->setRange(0, 126);
    customPlot_Q->xAxis->setRange(0, 126);

    customPlot_I->rescaleAxes(true);
    customPlot_Q->rescaleAxes(true);

    customPlot_I->replot();
    customPlot_Q->replot();

}
