#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QMetaType>
#include <QVector>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    init();
    set_connect();

    // Set Device Enable combo box items
    ui->device_enable_edit->addItem("Enable");
    ui->device_enable_edit->addItem("Disable");

    // Set Samples/Packet combo box items
    ui->sample_packet_edit->addItem("High");
    ui->sample_packet_edit->addItem("Low");

    ui->ia_gain_edit->setMaximum(65535);
    ui->frequency_periods_edit->setMaximum(255);

    // Set default values
    ui->filter_width_edit->setValue(10);                // Filter Width
    ui->sample_period_edit->setValue(4);                // Sample/Period
    ui->ia_gain_edit->setValue(900);                    // IA Gain
    ui->frequency_periods_edit->setValue(120);          // Frequency Periods

    ui->ClockOutputTestSignal_button->setChecked(false);  // Clock Output Test unchecked

    // If Device Enable is a QComboBox
    ui->device_enable_edit->setCurrentText("Enable");

    // If Samples/Packet is a QComboBox
    ui->sample_packet_edit->setCurrentText("High");
}



MainWindow::~MainWindow()
{

    if (data_thread->isRunning()) {
        data_thread->quit();
        data_thread->wait();
    }
    delete ui;
}

void MainWindow::init(){
    udp_data = new udp(this);

    data_thread = new QThread(this);
    data = new data_process();
    data->moveToThread(data_thread);
    data_thread->start();

    perf_timer = new QTimer(this);
    perf_timer->start(10000);

    recordingTimer = new QTimer(this);
    recordingTimer->setSingleShot(true);

    chartPlotter = new ChartPlotter(ui->customPlot_I, ui->customPlot_Q);
    qRegisterMetaType<QVector<qreal>>("QVector<qreal>");
    qRegisterMetaType<QVector<QVector<qreal>>>("QVector<QVector<qreal>>");



}

void MainWindow::set_connect(){


    // UDP
    connect(udp_data, &udp::emit_raw_data, data, &data_process::decode_data);
    connect(ui->ip_toggle_button, &QPushButton::clicked, this, &MainWindow::udp_connect_toggle);

    // Send initial configuration values
    connect(ui->SendConfiguration_button, &QPushButton::clicked, this, &MainWindow::SendConfiguration_button);
    connect(ui->SendFrequency_button, &QPushButton::clicked, this, &MainWindow::SendFrequency_button);
    connect(ui->SendSendingSequence_button, &QPushButton::clicked, this, &MainWindow::SendSendingSequence_button);
    connect(ui->SendExcitationSequence_button, &QPushButton::clicked, this, &MainWindow::SendExcitationSequence_button);

    // Perf
    connect(perf_timer, &QTimer::timeout, this, &MainWindow::perf_monitor);


    connect(data, &data_process::send_decoded_data,this, &MainWindow::updateRealtimeDisplay);

    connect(ui->browse_path_button, &QPushButton::clicked, this, &MainWindow::select_data_save_path_button);
    connect(data, &data_process::send_decoded_data, this, &MainWindow::on_new_decoded_data);
    connect(ui->data_save_button, &QPushButton::clicked, this, &MainWindow::startRecording);
    connect(recordingTimer, &QTimer::timeout, this, &MainWindow::stopRecording);


}

void MainWindow::perf_monitor(){
    qDebug() << "Received " + QString::number(data->get_perf_data()) + " data package in last 10 sec";
    data->reset_perf_data();
}


// Configure IP
void MainWindow::udp_connect_toggle(){

    QString pc_ip = ui->pc_ip_edit->text();       // Get pc_ip
    QString device_ip = ui->device_ip_edit->text(); // Get device_ip
    udp_data->udp_connect_toggle(pc_ip, device_ip); // Try to connect or disconnect UDP network
}

// Configure command
void MainWindow::SendConfiguration_button() {
    // 1. Get parameters from UI controls and clamp them into valid ranges
    int filterWidth   = qBound(4, ui->filter_width_edit->value(), 8192);        // Filter width (range 4~8192)
    int samplePeriod  = qBound(0, ui->sample_period_edit->value(), 255);        // Samples per period (range 0~255)
    int iaGain        = qBound(1, ui->ia_gain_edit->value(), 65535);            // IA Gain (range 1~65535)
    int clockTest     = ui->ClockOutputTestSignal_button->isChecked() ? 1 : 0;  // Clock output test signal enabled (1 means enabled)
    int freqPeriods   = qBound(0, ui->frequency_periods_edit->value(), 255);    // Frequency periods (range 0~255)

    // 2. Build configuration command string, e.g.: D1C10G3H3P4I900S1J120
    QString configCmd = QString("D1C%1G3H3P%2I%3S%4J%5")
                            .arg(filterWidth)     // After C → filter width
                            .arg(samplePeriod)    // After P → samples per period
                            .arg(iaGain)          // After I → IA gain
                            .arg(clockTest)       // After S → clock test signal switch
                            .arg(freqPeriods);    // After J → frequency periods

    // 3. Convert to byte array and send to device via UDP
    QByteArray data = configCmd.toUtf8();          // Convert string to UTF-8 byte stream
    udp_data->send_data(data);
}

// Sensing sequence command
void MainWindow::SendSendingSequence_button() {
    // 1. Get string from input box, e.g. S,2,3,4,...
    QString sequence = ui->SensingSequence_edit->toPlainText().trimmed();

    // 2. Convert to byte array and send
    QByteArray data = sequence.toUtf8();
    udp_data->send_data(data);
}

// Excitation sequence command
void MainWindow::SendExcitationSequence_button(){
    // 1. Get user input from Excitation text box (e.g. E,1,2,2,...)
    QString excitationText = ui->ExcitationSequence_edit->toPlainText().trimmed();

    // 2. Convert string to QByteArray for UDP sending
    QByteArray data = excitationText.toUtf8();

    // 3. Send to target device
    udp_data->send_data(data);
}

// Frequency configuration command
void MainWindow::SendFrequency_button()
{
    QVector<double> frequencyArray;

    // 1. Read frequency config string from input box and trim spaces
    QString freqText = ui->FrequencyConfiguration_edit->toPlainText().trimmed();

    // 2. Split string by comma "," to get individual frequency strings
    QStringList individualFrequenciesList = freqText.split(",", Qt::SkipEmptyParts);
    frequencyArray.clear();

    // 3. Convert each frequency string to double and store in frequencyArray
    for (const QString &individualFrequency : individualFrequenciesList){
        bool ok;
        double frequencyValue = individualFrequency.trimmed().toDouble(&ok);
        if (ok)
            frequencyArray.append(frequencyValue);
        else
            qDebug() <<"Conversion failed for frequency: " + individualFrequency;
    }

    // 4. Record frequencyArray values (for debugging)
    QStringList frequencyStrList;
    for (double d : frequencyArray)
        frequencyStrList << QString::number(d);

    // 5. Each frequency divided by 8 and rounded, stored as quint16 → lo (lower 16 bits)
    QVector<quint16> frequencyArrayIntlo;
    for (double freq : frequencyArray){
        frequencyArrayIntlo.append(static_cast<quint16>(qRound(freq/8.0)));
    }

    // 6. Print lo values (debugging)
    QStringList loList;
    for (quint16 v : frequencyArrayIntlo)
        loList << QString::number(v);

    // 7. Build 32-bit values (high 16 bits from phaseOffsetArray, low 16 bits from lo)
    QVector<quint32> joinedValueArray;
    joinedValueArray.clear();
    int joinCount = qMin(frequencyArrayIntlo.size(),phaseOffsetArray.size());
    for (int i = 0; i < joinCount; ++i){
        quint32 joined = (static_cast<quint16>(phaseOffsetArray.at(i)) << 16) | frequencyArrayIntlo.at(i);
        joinedValueArray.append(joined);
    }

    // 8. Print joined 32-bit values (used for final command)
    QStringList joinedList;
    for (quint32 j : joinedValueArray)
        joinedList << QString::number(j);

    // 9. Build final command string: F 0 0 A B C D E
    // If fewer than 5 frequencies, pad with "0"
    QStringList finalValues;
    for (int i = 0; i < 5; ++i){
        finalValues << (i < joinedValueArray.size() ? QString::number(joinedValueArray.at(i)) : "0");
    }
    QString finalFrequencyMessage = "F 0 0 " + finalValues.join(" ");

    // 10. Convert command string to byte array and send via UDP
    QByteArray data = finalFrequencyMessage.toUtf8();
    udp_data->send_data(data);
}


void MainWindow::updateRealtimeDisplay(const QVector<QVector<qreal>> &data)
{
    if (data.isEmpty()) return;

    QVector<qreal> values = data.last();  // Always display the latest group
    ui->ras_freq_edit->setText(QString::number(values[0], 'f', 2));
    ui->sen_coil_edit->setText(QString::number(values[1], 'f', 2));
    ui->exc_coil_edit->setText(QString::number(values[2], 'f', 2));
    ui->adc_edit->setText(QString::number(values[3], 'f', 0));
    ui->otr_edit->setText(QString::number(values[4], 'f', 0));
    ui->i_data_edit->setText(QString::number(values[5], 'f', 6));
    ui->std_freq_edit->setText(QString::number(values[6], 'f', 2));
    ui->q_data_edit->setText(QString::number(values[7], 'f', 6));
}



void MainWindow::select_data_save_path_button(){
    QString folderPath = QFileDialog::getExistingDirectory(this, "Select Data Save Path", "", QFileDialog::ShowDirsOnly);
    if (folderPath !=""){
        data_save_path = folderPath;
        ui->data_path_edit->setText(data_save_path);
        ui->data_save_button->setDisabled(false);
        qDebug()<<"Data save path updated: "<< data_save_path;
    }
}


// Store all incoming decoded data
void MainWindow::on_new_decoded_data(const QVector<QVector<qreal>> &data) {
    // tryExtract10thGroup(data);
    tryExtractOrderedGroup(data);

    if (!isRecording) return;
    for (const auto &decoded_data_block : data) {
        recordingBuffer.append(decoded_data_block);
        timestampBuffer.append(QDateTime::currentDateTime());  // Record arrival timestamp immediately
    }
}

void MainWindow::startRecording() {
    if (data_save_path.isEmpty()) {
        qDebug() << "Please select the Data Save Path first...";
        return;
    }

    // Reset state
    recordingBuffer.clear();
    isRecording = true;
    ui->data_save_button->setEnabled(false);
    ui->data_save_button->setText("Recording…");

    // Automatically stop and save after 20 seconds
    recordingTimer->start(20000);
}

void MainWindow::stopRecording() {
    isRecording = false;
    ui->data_save_button->setEnabled(true);
    ui->data_save_button->setText("Start Save");

    // Copy and clear both buffers
    auto dataToSave = recordingBuffer;
    auto timesToSave = timestampBuffer;
    recordingBuffer.clear();
    timestampBuffer.clear();

    // Async write to disk: pass both buffers to save function
    QtConcurrent::run([this, dataToSave, timesToSave]() {
        save_data_to_csv(dataToSave, timesToSave);
    });
}

void MainWindow::save_data_to_csv(const QVector<QVector<qreal>>& decoded_data_buffer,
                                  const QVector<QDateTime>& timestamp_buffer) {
    if (data_save_path.isEmpty()) {
        qDebug() << "No path selected!";
        return;
    }

    QString time = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss-zzz");
    QString fileName = data_save_path + "/Coil16_DataSave_" + time + ".csv";
    QFile file(fileName);
    QTextStream out(&file);

    if (!file.exists()) {
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            out << "Ras Freq, Sen Coil, Exc Coil, ADC, OTR, I Data, Std Freq, Q Data, TimeStamp\n";
            file.close();
        }
    }
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        int n = qMin(decoded_data_buffer.size(), timestamp_buffer.size());
        for (int i = 0; i < n; ++i) {
            const auto& decoded_data_block = decoded_data_buffer.at(i);
            out << decoded_data_block.at(0) << ", "
                << decoded_data_block.at(1) << ", "
                << decoded_data_block.at(2) << ", "
                << decoded_data_block.at(3) << ", "
                << decoded_data_block.at(4) << ", "
                << decoded_data_block.at(5) << ", "
                << decoded_data_block.at(6) << ", "
                << decoded_data_block.at(7) << ", "
                << timestamp_buffer.at(i).toString("yyyy-MM-dd_hh-mm-ss-zzz")
                << ", "
                << Qt::endl;
        }
        file.close();
    }
}





void MainWindow::tryExtractOrderedGroup(const QVector<QVector<qreal>>& dataStream)
{
    static bool collecting = false;
    static QMap<QPair<int, int>, QVector<qreal>> channelMap;
    static QList<QVector<qreal>> tempChannelRows;

    // Arrange in unique order of excitation < sensing, with 0 treated as 16
    static const QList<QPair<int, int>> channelOrder = []() {
        QList<QPair<int, int>> order;
        for (int i = 1; i <= 16; ++i) {
            for (int j = i + 1; j <= 16; ++j) {
                order.append({i, j});
            }
        }
        return order;
    }();

    for (const auto& row : dataStream)
    {
        int exc = static_cast<int>(row[2]);
        int sen = static_cast<int>(row[1]);

        // Replace 0 with 16 (coil 16)
        if (exc == 0) exc = 16;
        if (sen == 0) sen = 16;

        // Detect start point
        if (!collecting && exc == 1 && sen == 2) {
            collecting = true;
            tempChannelRows.clear();
            channelMap.clear();
            // qDebug() << "[START] Begin collecting from (1,2)";
        }

        if (!collecting)
            continue;

        // Collect a group of 4 rows
        tempChannelRows.append(row);

        if (tempChannelRows.size() == 4)
        {
            // Use unordered combination key (undirected channel)
            QPair<int, int> key = { qMin(exc, sen), qMax(exc, sen) };

            if (!channelMap.contains(key)) {
                channelMap[key] = tempChannelRows.last(); // Take the 4th row of data
                // qDebug() << "[CHANNEL] Added channel:" << key;
            }

            tempChannelRows.clear();

            // If all 120 channels are collected
            if (channelMap.size() == channelOrder.size())
            {
                QVector<QVector<qreal>> orderedGroup;

                for (const auto& key : channelOrder) {
                    if (channelMap.contains(key)) {
                        orderedGroup.append(channelMap[key]);
                    } else {
                        qDebug() << "[MISSING] Channel missing:" << key;
                        orderedGroup.append(QVector<qreal>()); // Add empty row to prevent crash
                    }
                }

                plot_buffer = orderedGroup;
                collecting = false;
                channelMap.clear();
                // qDebug() << "[SUCCESS] 120-channel group ready. plot_buffer size:" << plot_buffer.size();
            }
        }
    }
}



void MainWindow::on_startPlotButton_clicked()
{
    if (!plot_buffer.isEmpty())
    {
        chartPlotter->drawBarChart(plot_buffer);
        plot_buffer.clear(); // Clear after plotting, wait for next group
    } else {
        qDebug() << "plot_buffer is empty!";
    }
}
