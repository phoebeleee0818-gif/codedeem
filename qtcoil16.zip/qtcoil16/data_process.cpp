#include "data_process.h"

data_process::data_process(QObject *parent)
    : QObject{parent}
{}

void data_process::decode_data(const QByteArray &raw_data) {
    if (raw_data.size() == 0){
        return;
    }

    // Calculate buffer size: raw data length divided by bytes per sample
    int buffer_size = raw_data.size() / SAMPLE_SIZE;

    // Create a 2D list to store decoded data blocks
    QVector<QVector<qreal>> temp_buffer;
    // Reserve enough space to avoid frequent reallocations
    temp_buffer.resize(buffer_size);

    // Create a task list for concurrent decoding
    QList<QFuture<void>> tasks;

    // Iterate over raw data, processing one SAMPLE_SIZE block each time
    for (int offset = 0; offset < raw_data.size(); offset += SAMPLE_SIZE) {
        data_received++;
        // Extract current block from raw_data
        QByteArray block_data = raw_data.mid(offset, SAMPLE_SIZE);
        // Reverse byte order (depending on protocol/format requirements)
        std::reverse(block_data.begin(), block_data.end());
        // Calculate current block index in the buffer
        int index = offset / SAMPLE_SIZE;

        // Submit decoding task to QtConcurrent for parallel execution
        tasks.append(QtConcurrent::run([=, &temp_buffer]() {
            // Decode current data block, return float list
            QVector<qreal> decoded_data_block = decode_block(block_data);
            // Write decoding result into temp_buffer at corresponding index
            temp_buffer[index] = decoded_data_block;
        }));
    }

    // Wait for all concurrent tasks to finish
    for (auto& task : tasks) {
        task.waitForFinished();
    }

    {
        // Lock shared data to prevent concurrent write conflicts
        QMutexLocker locker(&mutex);
        // Replace temporary buffer with member variable decoded_data_buffer
        decoded_data_buffer = temp_buffer;
        // Reset data read index
        data_index = 0;
    }

    emit send_decoded_data(decoded_data_buffer); // emit signal
}


QVector<qreal> data_process::decode_block(const QByteArray &block_data) {
    // Return QVector<qreal>, field order:
    // [Ras Freq, Sen Coil, Exc Coil, ADC, OTR, I Data, Std Freq, Q Data]
    // Initialize output list, default value -1 means invalid or unparsed
    QVector<qreal> data = {-1, -1, -1, -1, -1, -1, -1, -1};

    // Input length check: if not equal to SAMPLE_SIZE, return default list
    if (block_data.size() != SAMPLE_SIZE) {
        return data;
    }

    // Split block_data into 4 segments, each 8 bytes for different decoding
    for (int i = 0; i < 4; ++i) {
        // Extract 8-byte hex string for segment i
        QByteArray block = block_data.mid(i * 8, 8);

        // Parse hex string into unsigned integer
        bool ok;
        quint32 raw = block.toUInt(&ok, 16);
        if (!ok) {
            // Skip this segment if parsing fails, keep -1 in data
            continue;
        }

        // Decode according to segment index i
        switch (i) {
        case 0:
            // Segment 0: Q Data, normalized by 2^31
            data[7] = static_cast<qreal>(raw) / qPow(2.0, 31.0);
            break;
        case 1:
            // Segment 1: Std Freq, multiplied by factor 8
            data[6] = static_cast<qreal>(raw) * 8;
            break;
        case 2:
            // Segment 2: I Data, normalized by 2^31
            data[5] = static_cast<qreal>(raw) / qPow(2.0, 31.0);
            break;
        case 3:
            // Segment 3: Composite field, split by bit operations
            // High 4 bits -> OTR; next 4 bits -> ADC; next 4 bits -> Exc Coil; next 4 bits -> Sen Coil;
            // Low 16 bits -> Ras Freq (scaled by *8)
            data[4] = static_cast<qreal>((raw >> 28) & 0xF);      // OTR
            data[3] = static_cast<qreal>((raw >> 24) & 0xF);      // ADC
            data[2] = static_cast<qreal>((raw >> 20) & 0xF);      // Exc Coil
            data[1] = static_cast<qreal>((raw >> 16) & 0xF);      // Sen Coil
            data[0] = static_cast<qreal>((raw & 0xFFFF) * 8);    // Ras Freq, 16-bit scaled by *8
            break;
        default:
            // Unreachable
            break;
        }
    }

    // Return parsed data list
    return data;
}

int data_process::get_perf_data(){
    QMutexLocker locker(&mutex);
    return data_received;
}

void data_process::reset_perf_data(){
    QMutexLocker locker(&mutex);
    data_received = 0;
}
