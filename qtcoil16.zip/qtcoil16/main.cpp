#include "mainwindow.h"

#include <QApplication>
#include <QCoreApplication>

int main(int argc, char *argv[])
{
    qRegisterMetaType<QVector<QVector<qreal>>>("QVector<QVector<qreal>>");
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);//dpi
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}

